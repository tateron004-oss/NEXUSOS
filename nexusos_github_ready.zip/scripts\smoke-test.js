const http = require("http");

const base = process.env.NEXUSOS_URL || "http://127.0.0.1:4288";
let cookie = "";

function request(path, options = {}) {
  const url = new URL(path, base);
  const body = options.body ? JSON.stringify(options.body) : null;
  return new Promise((resolve, reject) => {
    const req = http.request(url, {
      method: options.method || "GET",
      headers: {
        "content-type": "application/json",
        ...(cookie ? { cookie } : {}),
        ...(body ? { "content-length": Buffer.byteLength(body) } : {})
      }
    }, res => {
      const setCookie = res.headers["set-cookie"];
      if (setCookie?.length) cookie = setCookie.map(item => item.split(";")[0]).join("; ");
      let data = "";
      res.on("data", chunk => data += chunk);
      res.on("end", () => {
        const parsed = data ? JSON.parse(data) : {};
        if (res.statusCode < 200 || res.statusCode >= 300) {
          reject(new Error(`${path} failed: ${res.statusCode} ${parsed.error || data}`));
          return;
        }
        resolve(parsed);
      });
    });
    req.on("error", reject);
    if (body) req.write(body);
    req.end();
  });
}

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

async function main() {
  const health = await request("/api/healthz");
  assert(health.ok && health.app === "NexusOS", "health check failed");

  const readiness = await request("/api/readiness");
  assert(readiness.ok, "readiness check failed");

  const intake = await request("/api/public/intake", {
    method: "POST",
    body: {
      name: "Family Test Client",
      email: "family@example.com",
      phone: "555-555-0111",
      businessName: "Family Catering Studio",
      industry: "Catering",
      location: "Charlotte",
      needs: "I need a landing page, AI assistant, phone follow-up, social media posts, and lead tracking."
    }
  });
  assert(intake.ok && intake.client?.slug, "public intake automation failed");
  assert(intake.landingUrl.includes("/landing-page/index.html"), "public intake landing page failed");

  const auth = await request("/api/auth/login", {
    method: "POST",
    body: {
      email: process.env.NEXUSOS_ADMIN_EMAIL || "admin@nexusos.local",
      password: process.env.NEXUSOS_ADMIN_PASSWORD || "nexusos-admin"
    }
  });
  assert(auth.user?.email, "login failed");

  const built = await request("/api/business/build", {
    method: "POST",
    body: {
      request: "Client: mobile detailing business in Atlanta. Needs social media, AI assistant, phone assistant, lead follow-up, and a landing page.",
      objective: "Build production smoke test client",
      audience: "small business owner",
      urgency: "high"
    }
  });
  assert(built.kit.info.slug, "business kit did not return a slug");

  const detail = await request(`/api/client?slug=${built.kit.info.slug}`);
  assert(detail.workspace.assistantStudio, "assistant studio missing from workspace");

  detail.workspace.leads[0].stage = "interested";
  detail.workspace.socialPosts[0].status = "ready";
  detail.workspace.landingPage.headline = "NexusOS smoke test landing page";

  const saved = await request("/api/client/workspace", {
    method: "POST",
    body: { slug: built.kit.info.slug, workspace: detail.workspace }
  });
  assert(saved.workspace.leads[0].stage === "interested", "workspace save failed");

  const landing = await request("/api/client/landing-page", {
    method: "POST",
    body: { slug: built.kit.info.slug, workspace: saved.workspace }
  });
  assert(landing.landingUrl.includes("/landing-page/index.html"), "landing page creation failed");

  const assistantTest = await request("/api/client/assistant/test", {
    method: "POST",
    body: {
      slug: built.kit.info.slug,
      workspace: saved.workspace,
      message: "I need a quote today."
    }
  });
  assert(assistantTest.reply.includes("quote"), "assistant test reply failed");

  const assistantPackage = await request("/api/client/assistant/package", {
    method: "POST",
    body: { slug: built.kit.info.slug, workspace: saved.workspace }
  });
  assert(assistantPackage.files.length === 3, "assistant package export failed");

  const sms = await request("/api/phone/send-sms", {
    method: "POST",
    body: { to: "+15555550123", message: "NexusOS smoke test message" }
  });
  assert(["simulated", "live-sms"].includes(sms.mode), "SMS endpoint failed");

  console.log("NexusOS smoke test passed");
  console.log(`Client: ${built.kit.info.businessName}`);
  console.log(`Landing: ${base}${landing.landingUrl}`);
  console.log(`Assistant files: ${assistantPackage.files.length}`);
  console.log(`SMS mode: ${sms.mode}`);
}

main().catch(error => {
  console.error(error.message);
  process.exit(1);
});
